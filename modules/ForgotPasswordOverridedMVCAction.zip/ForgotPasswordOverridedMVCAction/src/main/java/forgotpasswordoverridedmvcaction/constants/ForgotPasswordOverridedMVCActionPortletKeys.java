package forgotpasswordoverridedmvcaction.constants;

/**
 * @author root322
 */
public class ForgotPasswordOverridedMVCActionPortletKeys {

	public static final String FORGOTPASSWORDOVERRIDEDMVCACTION =
		"forgotpasswordoverridedmvcaction_ForgotPasswordOverridedMVCActionPortlet";

}